angular.module('jcs-autoValidate', []);

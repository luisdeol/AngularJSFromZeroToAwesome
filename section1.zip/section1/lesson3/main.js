var app = angular.module('minmax', []);

// https://minmax-server.herokuapp.com/register/'
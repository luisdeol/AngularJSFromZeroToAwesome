angular-auto-validate
=====================

See http://jonsamwell.github.io/angular-auto-validate/ and my original blog post for more information http://jonsamwell.com/dynamic-angularjs-validation/